var iotf = require("ibmiotf");

function command(params) {
	
// console.log(params);
	
var orgId = params.orgId;
var clientId = params.deviceId;
var rule = params.ruleName;
var deviceType = clientId.split(':')[1];
var deviceId = clientId.split(':')[2];

var appClientConfig = {
	org: orgId,
    id: new Date().getTime()+'',
    "domain": "internetofthings.ibmcloud.com",
    "auth-key": 'a-yq8qg5-gkmflvplm7',
    "auth-token": 'AqSFS4@zNzwN?aXf(H'
 };
  
 var payload = {
       "reason": params.ruleName,
       "stop":true
 };

  var appClient = new iotf.IotfApplication(appClientConfig);
  appClient.log.setLevel('info');
  appClient.connect();
  console.log("connected to platform");
  console.log("Prepared to Connect & pass 'Maintenance Stop' command");
  appClient.on('connect', function () {
      appClient.publishDeviceCommand(deviceType,deviceId, "maintenance_command", "json", payload);
	  console.log("Published 'Maintenance Stop' command");
      appClient.disconnect();
  });
}
exports.main = command;